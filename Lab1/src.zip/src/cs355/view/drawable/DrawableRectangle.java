package cs355.view.drawable;

import cs355.model.drawing.Rectangle;
import cs355.model.drawing.Shape;

import java.awt.*;
import java.awt.geom.Point2D;

/**
 * Created by allenliao on 1/24/17.
 */
public class DrawableRectangle extends DrawableShape {

    private Point2D up_left;
    private double height;
    private double width;

    public DrawableRectangle(Shape s) {
        super(s);
        up_left = ((Rectangle)s).getUpperLeft();
        height = ((Rectangle)s).getHeight();
        width = ((Rectangle)s).getWidth();
    }

    @Override
    public void draw(Graphics2D g2d){
        g2d.setColor(getColor());
        g2d.fillRect((int)up_left.getX(), (int)up_left.getY(), (int)width, (int)height);
    }
}
