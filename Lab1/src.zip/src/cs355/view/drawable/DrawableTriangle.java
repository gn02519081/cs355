package cs355.view.drawable;

import cs355.model.drawing.Shape;
import cs355.model.drawing.Triangle;

import java.awt.*;
import java.awt.geom.Point2D;

/**
 * Created by allenliao on 1/24/17.
 */
public class DrawableTriangle extends DrawableShape {

    private Point2D point_a;
    private Point2D point_b;
    private Point2D point_c;

    public DrawableTriangle(Shape s) {
        super(s);
        point_a = ((Triangle)s).getA();
        point_b = ((Triangle)s).getB();
        point_c = ((Triangle)s).getC();
    }

    @Override
    public void draw(Graphics2D g2d){
        g2d.setColor(getColor());

        int points = 3;
        int[] x = new int[points];
        int[] y = new int[points];

        x[0] = (int) point_a.getX();
        y[0] = (int) point_a.getY();

        x[1] = (int) point_b.getX();
        y[1] = (int) point_b.getY();

        x[2] = (int) point_c.getX();
        y[2] = (int) point_c.getY();

        g2d.fillPolygon(x, y, points);

    }
}
