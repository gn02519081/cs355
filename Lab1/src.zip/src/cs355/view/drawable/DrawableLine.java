package cs355.view.drawable;

import cs355.model.drawing.Line;
import cs355.model.drawing.Shape;

import java.awt.*;
import java.awt.geom.Point2D;

/**
 * Created by allenliao on 1/23/17.
 */
public class DrawableLine extends DrawableShape {

    private Point2D start_point;
    private Point2D end_point;


    public DrawableLine(Shape s) {
        super(s);
        start_point = ((Line)s).getStart();
        end_point = ((Line)s).getEnd();
    }

    @Override
    public void draw(Graphics2D g2d){
        g2d.setColor(getColor());
        g2d.drawLine((int)start_point.getX(), (int)start_point.getY(), (int)end_point.getX(), (int)end_point.getY());
    }
}
