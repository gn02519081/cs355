package cs355.view.drawable;

import cs355.model.drawing.Shape;
import cs355.model.drawing.Square;

import java.awt.*;
import java.awt.geom.Point2D;

/**
 * Created by allenliao on 1/24/17.
 */
public class DrawableSquare extends DrawableShape {

    private Point2D up_left;
    private double length;

    public DrawableSquare(Shape s) {
        super(s);
        up_left = ((Square)s).getUpperLeft();
        length = ((Square)s).getSize();
    }


    @Override
    public void draw(Graphics2D g2d){
        g2d.setColor(getColor());
        g2d.fillRect((int)up_left.getX(), (int)up_left.getY(), (int)length, (int)length);

    }
}
