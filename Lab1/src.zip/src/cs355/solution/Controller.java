package cs355.solution;

import cs355.GUIFunctions;
import cs355.controller.CS355Controller;
import cs355.model.drawing.*;
import cs355.model.drawing.Rectangle;
import cs355.model.drawing.Shape;
import cs355.solution.Drawing;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.io.File;
import java.util.Iterator;

import static cs355.solution.Controller.State.Line;
import static cs355.solution.Controller.State.Square;

/**
 * Created by allenliao on 1/22/17.
 */
public class Controller implements CS355Controller {

//create enum for shape enum state = {Line, ......}

    // GUI function change color


    public Controller() {
    }

    public enum State{
        Line, Circle, Ellipse, Rectangle, Square, Triangle
    }

    private Color currentColor;
    private State currentShape;
    private Shape shapeSelected;
    private Point2D.Double start_point;
    //private Point2D.Double end_point;
    private Point2D.Double T_point_1 = null;
    private Point2D.Double T_point_2 = null;
    private Point2D.Double T_point_3 = null;

    @Override
    public void colorButtonHit(Color c) {
        currentColor = c;
        Drawing.SINGLETON.setCurrentColor(currentColor);
        GUIFunctions.changeSelectedColor(currentColor);
    }

    @Override
    public void lineButtonHit() {
        currentShape = State.Line;
    }

    @Override
    public void squareButtonHit() {
        currentShape = State.Square;
    }

    @Override
    public void rectangleButtonHit() {
        currentShape = State.Rectangle;
    }

    @Override
    public void circleButtonHit() {
        currentShape = State.Circle;
    }

    @Override
    public void ellipseButtonHit() {
        currentShape = State.Ellipse;
    }

    @Override
    public void triangleButtonHit() {
        currentShape = State.Triangle;
    }

    @Override
    public void selectButtonHit() {

    }

    @Override
    public void zoomInButtonHit() {

    }

    @Override
    public void zoomOutButtonHit() {

    }

    @Override
    public void hScrollbarChanged(int value) {

    }

    @Override
    public void vScrollbarChanged(int value) {

    }

    @Override
    public void openScene(File file) {

    }

    @Override
    public void toggle3DModelDisplay() {

    }

    @Override
    public void keyPressed(Iterator<Integer> iterator) {

    }

    @Override
    public void openImage(File file) {

    }

    @Override
    public void saveImage(File file) {

    }

    @Override
    public void toggleBackgroundDisplay() {

    }

    @Override
    public void saveDrawing(File file) {
        Drawing.SINGLETON.save(file);
    }

    @Override
    public void openDrawing(File file) {
        Drawing.SINGLETON.open(file);
    }

    @Override
    public void doDeleteShape() {

    }

    @Override
    public void doEdgeDetection() {

    }

    @Override
    public void doSharpen() {

    }

    @Override
    public void doMedianBlur() {

    }

    @Override
    public void doUniformBlur() {

    }

    @Override
    public void doGrayscale() {

    }

    @Override
    public void doChangeContrast(int contrastAmountNum) {

    }

    @Override
    public void doChangeBrightness(int brightnessAmountNum) {

    }

    @Override
    public void doMoveForward() {

    }

    @Override
    public void doMoveBackward() {

    }

    @Override
    public void doSendToFront() {

    }

    @Override
    public void doSendtoBack() {

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("Mouse Click");

        if (currentShape == State.Triangle){
            Point2D.Double point = new Point2D.Double(e.getX(),e.getY());

            if (T_point_1 == null){
                T_point_1 = point;
            }else if (T_point_2 == null){
                T_point_2 = point;
            }else if (T_point_3 == null){
                T_point_3 = point;
                shapeSelected = new Triangle(currentColor, T_point_1, T_point_2, T_point_3);
                Drawing.SINGLETON.addShape(shapeSelected);
                Drawing.SINGLETON.updateView();
                T_point_1 = null;
                T_point_2 = null;
                T_point_3 = null;
            }
        }
    }




    @Override
    public void mousePressed(MouseEvent e) {
        System.out.println("Mouse Pressed");


        Point2D.Double point = new Point2D.Double(e.getX(),e.getY());
        start_point = point;

        switch (currentShape){
            case Line:
                shapeSelected = new Line(currentColor, point, point);
                Drawing.SINGLETON.addShape(shapeSelected);
                break;
            case Circle:
                shapeSelected = new Circle(currentColor, point, 0);
                Drawing.SINGLETON.addShape(shapeSelected);
                break;
            case Ellipse:
                shapeSelected = new Ellipse(currentColor, point, 0, 0);
                Drawing.SINGLETON.addShape(shapeSelected);
                break;
            case Rectangle:
                shapeSelected = new Rectangle(currentColor, point, 0, 0);
                Drawing.SINGLETON.addShape(shapeSelected);
                break;
            case Square:
                shapeSelected = new Square(currentColor, point, 0);
                Drawing.SINGLETON.addShape(shapeSelected);
                break;
//            case Triangle:
//                shapeSelected = new Triangle(currentColor, point, point, point);
//                Drawing.SINGLETON.addShape(shapeSelected);
//                break;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

        System.out.println("Mouse Released");

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

        System.out.println("Mouse Dragged");

        //double x = e.getX();
        //double y = e.getY();
        Point2D.Double point = new Point2D.Double(e.getX(),e.getY());

        switch (currentShape){
            case Line:
                ((Line)shapeSelected).setEnd(point);
                Drawing.SINGLETON.updateView();
                break;
            case Circle:
                editCircle(e, (Circle)shapeSelected);
                Drawing.SINGLETON.updateView();
                break;
            case Ellipse:
                editEllipse(e, (Ellipse)shapeSelected);
                Drawing.SINGLETON.updateView();
                break;
            case Rectangle:
                editRectangle(e, (Rectangle)shapeSelected);
                Drawing.SINGLETON.updateView();
                break;
            case Square:
                editSquare(e, (Square)shapeSelected);
                Drawing.SINGLETON.updateView();
                break;
            case Triangle:
                break;
        }

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    public void editSquare(MouseEvent e, Square s){

        Point2D.Double dragPoint = new Point2D.Double(e.getX(),e.getY());

        double height = dragPoint.getY() - start_point.getY();
        double width = dragPoint.getX() - start_point.getX();
        double length = Math.min(Math.abs(height), Math.abs(width));

        s.setSize(length);

        if (width > 0){
            if (height > 0){
                s.setUpperLeft(start_point);
            }else{
                Point2D.Double up_left = new Point2D.Double(start_point.getX(), start_point.getY()-length);
                s.setUpperLeft(up_left);
            }
        }else{
            if (height > 0){
                Point2D.Double up_left = new Point2D.Double(start_point.getX()-length, start_point.getY());
                s.setUpperLeft(up_left);

            }else{
                Point2D.Double up_left = new Point2D.Double(start_point.getX()-length, start_point.getY()-length);
                s.setUpperLeft(up_left);
            }
        }
    }

    public void editRectangle(MouseEvent e, Rectangle s){

        Point2D.Double dragPoint = new Point2D.Double(e.getX(), e.getY());

        double height = dragPoint.getY() - start_point.getY();
        double width = dragPoint.getX() - start_point.getX();

        s.setHeight(Math.abs(height));
        s.setWidth(Math.abs(width));

        if (width > 0){
            if (height > 0){
                s.setUpperLeft(start_point);
            }else{
                Point2D.Double up_left = new Point2D.Double(start_point.getX(), start_point.getY() - Math.abs(height));
                s.setUpperLeft(up_left);
            }
        }else{
            if (height > 0){
                Point2D.Double up_left = new Point2D.Double(start_point.getX() - Math.abs(width), start_point.getY());
                s.setUpperLeft(up_left);

            }else{
                Point2D.Double up_left = new Point2D.Double(start_point.getX() - Math.abs(width), start_point.getY() - Math.abs(height));
                s.setUpperLeft(up_left);
            }
        }
    }

    public void editCircle(MouseEvent e, Circle s){

        Point2D.Double dragPoint = new Point2D.Double(e.getX(), e.getY());
        double height = dragPoint.getY() - start_point.getY();
        double width = dragPoint.getX() - start_point.getX();

        double diameter = Math.min(Math.abs(height), Math.abs(width));
        double radius = diameter/2;

        s.setRadius(radius);
        Point2D.Double center = new Point2D.Double();

        if (width > 0){
            if (height > 0){
                center.setLocation(start_point.getX()+radius, start_point.getY()+radius);
                s.setCenter(center);
            }else{
                center.setLocation(start_point.getX()+radius, start_point.getY()-radius);
                s.setCenter(center);
            }
        }else{
            if (height > 0){
                center.setLocation(start_point.getX()-radius, start_point.getY()+radius);
                s.setCenter(center);

            }else{
                center.setLocation(start_point.getX()-radius, start_point.getY()-radius);
                s.setCenter(center);
            }
        }

    }

    public void editEllipse(MouseEvent e, Ellipse s){
        Point2D.Double dragPoint = new Point2D.Double(e.getX(), e.getY());

        double height = dragPoint.getY() - start_point.getY();
        double width = dragPoint.getX() - start_point.getX();

        s.setHeight(Math.abs(height));
        s.setWidth(Math.abs(width));

        Point2D.Double center = new Point2D.Double();

        if (width > 0){
            if (height > 0){
                center.setLocation(start_point.getX()+Math.abs(width)/2, start_point.getY()+Math.abs(height)/2);
                s.setCenter(center);
            }else{
                center.setLocation(start_point.getX()+Math.abs(width)/2, start_point.getY()-Math.abs(height)/2);
                s.setCenter(center);
            }
        }else{
            if (height > 0){
                center.setLocation(start_point.getX()-Math.abs(width)/2, start_point.getY()+Math.abs(height)/2);
                s.setCenter(center);
            }else{
                center.setLocation(start_point.getX()-Math.abs(width)/2, start_point.getY()-Math.abs(height)/2);
                s.setCenter(center);
            }
        }
    }

}
